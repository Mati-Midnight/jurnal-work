from flask import Flask, render_template
from data import db_session
from data.jobs import Jobs
from data.users import Users

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

@app.route('/')
@app.route('/sait')
def sait():
    job = db_sess.query(Jobs)
    user = db_sess.query(Users)
    return render_template("main.html", job=job, user=user)


if __name__ == '__main__':
    db_session.global_init("db/blogs.db")
    db_sess = db_session.create_session()
    app.run()